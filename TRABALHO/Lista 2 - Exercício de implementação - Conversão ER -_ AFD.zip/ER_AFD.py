from collections import deque
from dataclasses import dataclass
from typing import Any
from copy import deepcopy

@dataclass
class Estado:
    fonte: int

    def eq(self, other):
        if isinstance(other, Estado):
            return (
                set(self.fonte) == set(other.fonte)
            )
        return False
    
    def hash(self):
        return hash((self.fonte, self.simbolo, *self.alvo))
    
@dataclass
class Transicao:
    fonte: str
    simbolo: str
    alvo: str

    def eq(self, other):
        if isinstance(other, Transicao):
            return (
                self.fonte == other.fonte and
                self.simbolo == other.simbolo and
                self.alvo == other.alvo
            )
        return False
    
    def hash(self):
        return hash((self.fonte, self.simbolo, *self.alvo))

class ConstrutorArvore():
    operadores = {
        'concat': '.',
        'or': '|',
        'star': '*',
        'open_par': '(',
        'close_par': ')'
    }

    @classmethod
    def contruir_arvore(cls, er: str) -> 'SyntaxTree':
        return SyntaxTree(er, cls.operadores)

class SyntaxTreeNode:
    def __init__(self, simbolo: str):
        
        self.simbolo = simbolo
        self.nullable = simbolo in ('*', '&')
        self.firstpos = None
        self.lastpos = None
        self.id = None
        self.__filhoren = []

    @property
    def filhoren(self) -> 'list[Self]':
        return self.__filhoren
    
    @property
    def primeiro_filho(self) -> 'Self | None':
        return self.__get_filho(0)

    @property
    def ultimo_filho(self) -> 'Self | None':
        return self.__get_filho(1)

    def __get_filho(self, index: int) -> 'Self | None':
        try:
            return self.__filhoren[index]
        except:
            return None

    def append_filho(self, filho: 'Self') -> None:
        self.__filhoren.append(filho)


class SyntaxTree:
    def __init__(self, er: str, operadores:str):
        self.alfabeto(er, operadores)
        self.er_completo(er)
        self.root = SyntaxTreeNode(None)
        self.aux_stack = deque()
        self.criar_arvore(self.completed_er, self.root)
        self.__id_counter: int = 1
        self.__leaf_nodes = {}
        self.__followpos = {}
        self.processar(self.root)
        self.criar_followpos(self.root)
    
    def alfabeto(self, er: str, operadores:str) -> None:
        alphabet = {i for i in f'({er})#' if i not in operadores.values()}
        self.alphabet = alphabet

    
    def er_completo(self, er: str) -> None:
        masked_er = f'({er})#'
        new_er = ''
        
        for index, item in enumerate(masked_er[:-1]):
            next_item = masked_er[index + 1]
            if item in self.alphabet:
                new_er += item if next_item in [')', '*', '|'] else f'{item}.'
            elif item == ')':
                new_er += item if next_item in ['*', ')'] else f'{item}.'
            elif item == '*':
                new_er += item if next_item in ['.', '|', ')'] else f'{item}.'
            else:
                new_er += item

        self.completed_er = f'{new_er}#'


    def criar_arvore(self, er: str, root: SyntaxTreeNode) -> None:
        if len(er) == 1:
            root.simbolo = er
        else:
            operator, position = self.posicao_operador(er)
            root.simbolo = operator
            left, right = self.divide_er(er, position)
            root.append_filho(SyntaxTreeNode(None))
            self.criar_arvore(left, root.primeiro_filho)
            if right:
                root.append_filho(SyntaxTreeNode(None))
                self.criar_arvore(right, root.ultimo_filho)


    def posicao_operador(self, er):
        for oper in ['|', '.', '*']:
            self.aux_stack.clear()
            for index, item in enumerate(er[::-1]):
                if item == ')': self.aux_stack.append(item)
                elif item == '(': self.aux_stack.pop()
                elif not bool(self.aux_stack):
                    if item == oper:
                        return oper, len(er) - index - 1


    def divide_er(self, er: str, position: int) ->  str:
        left = er[:position]
        right = er[position + 1 :] if position > 0 else None
        new_list = []
        for i in [left, right]:
            if i:
                has_extra, carac = self.parentes_extras(i)
                if not has_extra:
                    if i[0] == '(' and i[-1] != '*': i = i[1:]
                    if i[-1] == ')': i = i[:-1]
                else:
                    if carac == '(':
                        i.replace(carac, '', 1)
                    elif carac == ')':
                        rev_s = i[::-1]
                        i = len(i) - rev_s.index(carac) - 1
                        i = i[:i] + i[i+1:]
            new_list.append(i)

        return new_list


    def parentes_extras(self, er: str) -> (bool, str):      
        stack = deque()
        for item in er:
            if item == '(': stack.append(item)
            elif item == ')':
                if not bool(stack):
                    return True, ')'
                else:
                    stack.pop()

        is_empty = not bool(stack)

        return not is_empty, '(' if not is_empty else None
    

    def processar(self, node: SyntaxTreeNode) -> None:
        if node.primeiro_filho is not None:
            self.processar(node.primeiro_filho)

        if node.ultimo_filho is not None:
            self.processar(node.ultimo_filho)

        self.defini_first_last(node)


    def defini_first_last(self, node: SyntaxTreeNode) -> None:
        if node.simbolo == '&':
            node.nullable = True

        elif node.simbolo == '|':

            node.firstpos = [
                pos
                for filho in [node.primeiro_filho, node.ultimo_filho]
                for pos in (filho.firstpos or [])
                if pos != []
            ]
            node.lastpos = [
                pos
                for filho in [node.primeiro_filho, node.ultimo_filho]
                for pos in (filho.lastpos or [])
                if pos != []
            ]

            if node.primeiro_filho.nullable or node.ultimo_filho.nullable:
                node.nullable = True

        elif node.simbolo == '*':
            node.firstpos = [pos for pos in node.primeiro_filho.firstpos if pos != []]
            node.lastpos = [pos for pos in node.primeiro_filho.lastpos if pos != []]
            node.nullable = True

        elif node.simbolo == '.':
            if node.primeiro_filho.nullable and node.ultimo_filho.nullable:
                node.nullable = True

            if node.primeiro_filho.nullable:
                node.firstpos = [
                    pos
                    for filho in [node.primeiro_filho, node.ultimo_filho]
                    for pos in filho.firstpos
                ]
            else:
                node.firstpos = [pos for pos in node.primeiro_filho.firstpos]

            if node.ultimo_filho.nullable:
                node.lastpos = [
                    pos
                    for filho in [node.primeiro_filho, node.ultimo_filho]
                    for pos in filho.lastpos
                ]
            else:
                node.lastpos = [pos for pos in node.ultimo_filho.lastpos]
        
        else:
            node.id = self.__id_counter
            self.__leaf_nodes[self.__id_counter] = node
            self.__followpos[self.__id_counter] = set()

            self.__id_counter += 1

            node.firstpos = [node.id]
            node.lastpos = [node.id]


    def criar_followpos(self, node: SyntaxTreeNode) -> None:
        if node.primeiro_filho is not None:
            self.criar_followpos(node.primeiro_filho)

        if node.ultimo_filho is not None:
            self.criar_followpos(node.ultimo_filho)

        if node.simbolo in ['.', '*']: self.definir_followpos(node)

    
    def definir_followpos(self, node: SyntaxTreeNode) -> None:
        if node.simbolo == '*':
            for n in node.lastpos:
                for id in node.firstpos:
                    self.__followpos[n].add(id)
        if node.simbolo == '.':
            for n in node.primeiro_filho.lastpos:
                for id in node.ultimo_filho.firstpos:
                    self.__followpos[n].add(id)


    def converter_afd(self):
        estados = [self.estado_inicial()]
        estados_visitados = []
        final_estados = []
        transicaos = []
        estado_inicial = self.root.firstpos
        
        final_id = list(self.__leaf_nodes.keys())[-1]
        while estados:
            state = estados.pop(0)
            estados_visitados.append(state)
            if final_id in state.fonte:
                final_estados.append(state)
            
            novas_transicoes = self.criar_transicoes(state)
            transicaos.extend(novas_transicoes)

            for transicao in novas_transicoes:
                if transicao.alvo != []:
                    novo_estado = transicao.alvo
                    state = Estado(novo_estado)
                    if not state in estados_visitados and not state in estados:
                        estados.append(state)
        return self.formato(estado_inicial, estados_visitados, final_estados, transicaos)
    

    def formato(self,
                     inicio: int,
                     all: Estado,
                     final: Estado,
                     transicaos: Transicao) -> str:
        str_automatofinito = ''


        str_automatofinito += f'{len(all)};'

        str_inicial = ",".join([str(i) for i in inicio])
        str_automatofinito += f'{{{str_inicial}}};'
                
        str_atual = []
        for final in final:
            str_atual.append(f'{{{",".join([str(i) for i in final.fonte])}}}')
        str_automatofinito += f'{{{",".join(str_atual)}}};'
        self.alphabet.remove('#')
        if '&' in self.alphabet:
            self.alphabet.remove('&')
        str_automatofinito += f'{{{",".join(sorted([letter for letter in self.alphabet]))}}};'
        for transicao in transicaos:
            if transicao.simbolo != '#':
                fonte = f'{{{",".join([str(i) for i in transicao.fonte.fonte])}}}'
                simbolo = f'{transicao.simbolo}'
                alvo = f'{{{",".join([str(i) for i in transicao.alvo])}}}'
                str_automatofinito += f'{fonte},{simbolo},{alvo};'
        print(str_automatofinito[:-1])



    def criar_transicoes(self, state: int):

        transicaos = {}
        for id in state.fonte:

            simbolo = self.__leaf_nodes[id].simbolo
            followpos = self.__followpos[id]
            if simbolo in transicaos:
                for i in followpos:
                    transicaos[simbolo].add(i)
            else:
                transicaos[simbolo] = set(followpos)
        
        transicaos_list = []
        for simbolo, alvo in transicaos.items():
            t = Transicao(state, simbolo, sorted(list(alvo)))
            transicaos_list.append(t)

        ordenar_transicoes = sorted(transicaos_list, key=lambda x: (x.simbolo))
        
        return ordenar_transicoes


    def estado_inicial(self) -> Estado:
        return Estado(self.root.firstpos)

class ConstrutorArvore():
    operadores = {
        'concat': '.',
        'or': '|',
        'star': '*',
        'open_par': '(',
        'close_par': ')'
    }

    @classmethod
    def contruir_arvore(cls, er: str) -> SyntaxTree:
        return SyntaxTree(er, cls.operadores)

# er = '(&|b)(ab)*(&|a)'
# er = 'aa*(bb*aa*b)*'
# er = 'a(a|b)*a'
# er = 'a(a*(bb*a)*)*|b(b*(aa*b)*)*'

er= input()
er_sem_espaco = er.replace(' ', '')
arvore = ConstrutorArvore.contruir_arvore(er_sem_espaco)
arvore.converter_afd()


